straddle-bolt-v1
